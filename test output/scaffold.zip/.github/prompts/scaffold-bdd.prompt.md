# /scaffold-bdd

## Purpose
Transform SQM Minion's BDD output into framework-aligned files. This is the **intelligent** alternative to running `npx ts-node scripts/scaffold-generated-test.ts`. Use this when:
- The script's hardcoded transformations don't fit a particular generated output
- You want flexibility for edge cases (unusual selectors, complex flows, etc.)
- You want to review transformations before committing

This command DOES NOT run the script. It does its own intelligent transformation using your framework conventions.

---

## Step 1 — Read inputs

Read these files in this order. If any are missing, report and STOP.

1. **`.features-gen/raw-output.txt`** — raw SQM Minion output (paste from chat)
2. **`.github/copilot-instructions.md`** — framework conventions (authoritative source for ALL patterns)
3. **`src/wpa/tests/UI/steps/fixtures.ts`** — to understand current fixtures.ts structure for updates
4. **`.features-gen/manifest.json`** — tracking file (create empty `{"scaffolds":[]}` if missing)

If `raw-output.txt` is empty or only whitespace:
- Tell user: "raw-output.txt is empty. Copy SQM Minion chat output (Ctrl+A → Ctrl+C) and paste into `.features-gen/raw-output.txt`, then re-run /scaffold-bdd"
- STOP

---

## Step 2 — Parse raw-output.txt

The format is markdown with these section headers (any case/punctuation variation accepted):
- `### Feature file` (or `Feature file:`, `Feature File:`, etc.)
- `### Fixture file` (or variations — **IGNORE this section, real fixtures.ts is updated separately**)
- `### Step definition file` (or `Step definitions:`, `Step Definitions`, etc.)
- `### Page object file` (or `Page class:`, `Page Object`, etc.)

Each section's content is inside ` ```typescript ` or ` ```gherkin ` fences.

Extract these 3 sections (skip fixture):
- `feature` — Gherkin source
- `steps` — TypeScript step definitions
- `page` — TypeScript Page Object class

If page section is missing, STOP and report.

---

## Step 3 — Detect & confirm metadata

From the page section, extract:
- **className** — from `export default class XYZ` (e.g. `MoneyMovementEnrollmentPage`)
- **fixtureVarName** — `className` with first letter lowercase (e.g. `moneyMovementEnrollmentPage`)

From the feature section, extract:
- **featureBase** — feature filename without `.feature` extension. If filename not present, derive from first part of feature file name split by `_` (e.g. `moneyMovementEnrollment.feature` → `moneyMovementEnrollment`)

Ask user to confirm:
```
📛 Detected class: <className>
🔑 Fixture name: <fixtureVarName>
📁 Feature base: <featureBase>
🎯 App type: SSE or PMM? (SSE uses 'When', PMM uses 'Then' for login step)

Confirm or provide corrections.
```

WAIT for user response before proceeding.

---

## Step 4 — Determine file destinations

Suggest paths based on the feature domain. Inspect existing folder structure under `src/wpa/pages/UI/` to find similar features. Suggest:

```
Page class:    src/wpa/pages/UI/<Domain>/<className>.ts
Constants:     src/wpa/constants/UI/<Domain>/<className>Constants.ts
Step defs:     src/wpa/tests/UI/steps/<Domain>/<fixtureBaseName>Steps.ts
Feature:       src/resources/features/UI/<Domain>/<featureBase>.feature
```

Where `<Domain>` is your best guess (e.g. `SelfEnrollment`, `Transactions`, `Accounts`). Ask user to confirm or provide overrides.

WAIT for user response.

---

## Step 5 — Transform Page class

Apply these transformations (in order):

### 5a. Strip generated imports — replace with framework-aligned imports
```typescript
import { Page } from '@playwright/test';
import UIActions from '@northerntrust-internal/sqm-atr-playwright-lib/web/actions/UIActions';
import Logger from '@northerntrust-internal/sqm-atr-playwright-lib/logger/Logger';
import ATRService from '@northerntrust-internal/sqm-atr-playwright-lib/utils/ATRService';
import CommonActionsPage from 'utils/CommonActionsPage';
import { <ClassName>Constants } from '@constants/UI/<Domain>/<ClassName>Constants';
```

### 5b. Replace class field declarations
```typescript
export default class <ClassName> {
  private web: UIActions;
  private logger: typeof Logger;
  private reporting: ATRService;
  private commonActions: CommonActionsPage;
  private testDataCache: Record<string, string> | null = null;

  constructor(private page: Page) {
    this.web = new UIActions(page);
    this.logger = Logger;
    this.reporting = new ATRService(page);
    this.commonActions = new CommonActionsPage(page);
  }
```

### 5c. Remove `readonly` constant declarations from the class
Move them to a separate constants file. Categorize:
- Ending in `_URL` → `urls`
- Ending in `_LABEL`, `_TEXT`, `_BUTTON`, `_PLACEHOLDER`, `_NAME`, `_OPTION`, `_OPTIONS` → `labels`
- Ending in `_VALUE`, `_VALUE_N` → **test data** (NOT in constants file; goes to Excel)
- Everything else → `selectors`

EXCLUDE login-related constants entirely (they belong in LoginPages):
- `USER_ID_LABEL`, `PASSWORD_LABEL`, `LOGIN_BUTTON_LABEL`, `PUSH_AUTH_LABEL`, `PUSH_OPTION_LABEL`, `LOGIN_URL`, `APP_LIST_URL`, `WEALTH_PASSPORT_URL`, `THIRD_APP_CARD_ICON`, `ENTER_KEY`, anything starting with `loginData`

### 5d. Replace inline string usages with constant references
For each non-`_VALUE` constant, replace `this.FOO_BAR` references in method bodies with `<ClassName>Constants.FOO_BAR`.

### 5e. Replace `_VALUE` usages with test data cache
For each `_VALUE` constant like `USER_ID_VALUE_1 = 'DEMOZZW1'`, replace usages with:
```typescript
this.testDataCache?.userId ?? ''  // field name derived from constant
```

Field name derivation: strip `_VALUE\d*` suffix, lowercase first letter. `USER_ID_VALUE_1` → `userId`. `TRANSFER_AMOUNT_VALUE` → `transferAmount`.

### 5f. Remove generated login method blocks
Remove ENTIRE method blocks (public/private async + name + body) matching these names:
`launchLoginPage`, `login`, `completePushAuth`, `openAppList`, `launchLogin`, `submitLogin`, `enterCredentials`, `navigateToLogin`, `clickUserIdField`, `enterUserId`, `clickPasswordField`, `enterPassword`, `submitWithEnterKey`, `clickLoginButton`, `selectPushOption`, `navigateToAppList`, `clickThirdAppCard`, `navigateToWealthPassport`

### 5g. Rename `atrService` → `this.reporting`

### 5h. Replace generated catch blocks
```typescript
} catch (error) {
  await atrService.logResult(...);
  throw error;
}
```
With:
```typescript
} catch (error) {
  return await this.handleError('<ClassName>', error);
}
```

### 5i. Inject `loadTestData` + `handleError` methods before closing class brace

```typescript
async loadTestData(testID: string, featureBaseName: string): Promise<void> {
  try {
    if (this.testDataCache) return;
    const excelFile = (this.commonActions as any).buildExcelFilePath(featureBaseName);
    const rows = await (this.commonActions as any).readExcelAsTableOfASheet(excelFile, featureBaseName);
    const row = rows.find((r: any) =>
      String(r.TestId).trim().toUpperCase() === testID.toUpperCase() &&
      String(r.ExecutionFlag ?? 'Y').trim().toUpperCase() === 'Y'
    );
    if (!row) throw new Error(`Test data not found for TestId=${testID} in sheet=${featureBaseName}`);
    this.testDataCache = row as Record<string, string>;
    this.logger.info(`Test data loaded for TestId=${testID}`);
    await this.reporting.logResult('Load test data', `TestId: ${testID}`, 'Test data loaded', 'Pass', 'Screenshot');
  } catch (error) {
    return await this.handleError('loadTestData', error);
  }
}

private async handleError(functionName: string, error: unknown): Promise<never> {
  const lineNumber = (error instanceof Error && error.stack)
    ? (error.stack.match(/<ClassName>\.ts:(\d+):\d+/)?.[1] ?? 'unknown')
    : 'unknown';
  this.logger.error(`${functionName} failed at line ${lineNumber}: ${error}`);
  await this.reporting.logResult(
    functionName,
    `Error at line ${lineNumber}: ${error}`,
    'Function Failed',
    'Fail',
    'Screenshot'
  );
  throw error;
}
```

---

## Step 6 — Transform Step Definitions

### 6a. Fix imports
```typescript
import { Given, When, Then } from '../fixtures';
```

### 6b. Remove generated page imports and `TestData` utility imports.

### 6c. Detect generated fixture variable name from `async ({ ... })` destructuring patterns. Rename to `<fixtureVarName>` everywhere.

### 6d. Rename `atrService` → `reporting`.

### 6e. Remove all login step definition blocks (matching `LOGIN_STEP_KEYWORDS` from script — any step containing phrases like "navigate to login page", "login with credentials", "complete push authentication", etc.)

### 6f. Add the 2 standard login step defs at the top (after imports):

```typescript
Given('I Navigate to Wealth Passport Application', async ({ loginPage, reporting }) => {
  try {
    await loginPage.launchApplication();
    await reporting.logResult(
      'Navigate to Wealth Passport Application',
      'Navigate to Wealth Passport Application',
      'Successfully to Navigate to Wealth Passport Application',
      'Pass', 'Screenshot'
    );
  } catch (error) {
    const errorMsg = (error && typeof error === 'object' && 'message' in error)
      ? (error as any).message : String(error);
    await reporting.logResult(
      'Navigate to Wealth Passport Application',
      'Navigate to Wealth Passport Application',
      'Failed to Navigate to Wealth Passport Application',
      'Fail', 'Screenshot', errorMsg
    );
  }
});

<When|Then>('The Wealth Passport Refresh application for <SSE|PMM> is loaded based on {string}',
  async ({ loginPage, reporting }, LoginUser: string) => {
    try {
      await loginPage.loginToWP(LoginUser);
      await reporting.logResult(
        'Launching the Playwright application',
        'Wealth Passport Page should load successfully',
        'Wealth Passport page loaded',
        'Pass', 'Screenshot'
      );
    } catch (error) {
      const errorMsg = (error && typeof error === 'object' && 'message' in error)
        ? (error as any).message : String(error);
      await reporting.logResult(
        'Launching the Playwright application',
        'Wealth Passport Page should load successfully',
        `Failed to load Wealth Passport page: ${errorMsg}`,
        'Fail', 'Screenshot'
      );
    }
});
```

Use `When` for SSE, `Then` for PMM. Use the matching app type name in the step text.

### 6g. Add `User loads test data for '<testID>'` step if page has `_VALUE` constants (i.e. uses test data).

### 6h. Simplify generated catch blocks to:
```typescript
} catch (error: any) {
  const errorMsg = (error && typeof error === 'object' && 'message' in error)
    ? (error as any).message : String(error);
  throw error;
}
```

---

## Step 7 — Transform Feature file

### 7a. Convert `Scenario:` → `Scenario Outline:`

### 7b. Remove ALL login-related steps from each scenario (matching LOGIN_STEP_KEYWORDS).

### 7c. Inject these 3 steps at the top of each scenario (once per scenario):
```gherkin
Given I Navigate to Wealth Passport Application
<When|Then> The Wealth Passport Refresh application for <SSE|PMM> is loaded based on "<LoginUser>"
And User loads test data for '<testID>'
```

(Skip third line if no `_VALUE` constants present.)

### 7d. Replace hardcoded `_VALUE` strings in steps with `<testID>` placeholder.

### 7e. Add `Examples:` table at end of each scenario:
```gherkin
    Examples:
      | LoginUser                          | testID            |
      | tran_ExternalAdminInitiator_DEMOW  | <featureBase>_001 |
```

### 7f. Ensure `@regression` tag is present (add if missing).

---

## Step 8 — Generate Constants file

Create `<ClassName>Constants.ts`:

```typescript
/**
 * <ClassName>Constants.ts
 * Auto-generated via /scaffold-bdd
 * Note: Test data values (_VALUE constants) are NOT here.
 *       They are loaded from Excel at runtime via loadTestData().
 */

export const <ClassName>Constants = {
  // URLs
  EXAMPLE_URL: 'https://...',

  // Labels & Placeholders
  EXAMPLE_LABEL: 'Example',

  // Selectors
  EXAMPLE_SELECTOR: 'div.example',
} as const;
```

Only include sections that have entries. Omit empty sections.

---

## Step 9 — Update fixtures.ts

Read current `fixtures.ts`. Find these 5 locations and add `<className>` entries:

### 9a. Imports section (after last import)
```typescript
import <ClassName> from '@pages/UI/<Domain>/<ClassName>';
```

### 9b. `PageObjects` interface (before closing `}`)
```typescript
  <fixtureVarName>: <ClassName>;
```

### 9c. `createPageObjects` registry (before `return registry;`)
```typescript
  registry.<fixtureVarName> = refreshInstance(registry.<fixtureVarName>, new <ClassName>(page));
```

### 9d. `resetPageObjects` arrow function — match pattern `const resetPageObjects = (newPage: Page): void => { ... }`. Add inside the function body:
```typescript
  registry.<fixtureVarName> = refreshInstance(registry.<fixtureVarName>, new <ClassName>(newPage));
```

### 9e. `test.extend<MyFixtures>({ ... })` block — add accessor before closing `});`
```typescript
  <fixtureVarName>: async ({ pageObjects }, use) => {
    await use(pageObjects.<fixtureVarName>);
  },
```

**SKIP if `import <ClassName> from` already exists** — already added.

---

## Step 10 — Write files & update manifest

Write all 4 generated files to their destination paths. Update `fixtures.ts`.

Append a new entry to `.features-gen/manifest.json`:

```json
{
  "scaffolds": [
    {
      "id": "<featureBase>-<ISO timestamp>",
      "feature": "<featureBase>",
      "className": "<ClassName>",
      "fixtureVarName": "<fixtureVarName>",
      "domain": "<Domain>",
      "timestamp": "<ISO 8601>",
      "files_created": [
        "src/wpa/pages/UI/<Domain>/<ClassName>.ts",
        "src/wpa/constants/UI/<Domain>/<ClassName>Constants.ts",
        "src/wpa/tests/UI/steps/<Domain>/<fixtureBaseName>Steps.ts",
        "src/resources/features/UI/<Domain>/<featureBase>.feature"
      ],
      "fixtures_modified": {
        "import_line": "import <ClassName> from '@pages/UI/<Domain>/<ClassName>';",
        "interface_entry": "<fixtureVarName>: <ClassName>;",
        "registry_entry": "registry.<fixtureVarName> = refreshInstance(registry.<fixtureVarName>, new <ClassName>(page));",
        "reset_entry": "registry.<fixtureVarName> = refreshInstance(registry.<fixtureVarName>, new <ClassName>(newPage));",
        "accessor_entry": "<fixtureVarName>: async ({ pageObjects }, use) => { await use(pageObjects.<fixtureVarName>); },"
      }
    }
  ]
}
```

The `id` field is used by `/scaffold-rollback`.

---

## Step 11 — Report

Print summary:

```
✅ SCAFFOLD COMPLETE

Files created:
  📄 src/wpa/pages/UI/<Domain>/<ClassName>.ts
  📄 src/wpa/constants/UI/<Domain>/<ClassName>Constants.ts
  📄 src/wpa/tests/UI/steps/<Domain>/<fixtureBaseName>Steps.ts
  📄 src/resources/features/UI/<Domain>/<featureBase>.feature

fixtures.ts updated:
  ✅ Import added
  ✅ Interface entry added
  ✅ Registry entry added
  ✅ Reset entry added
  ✅ Accessor entry added

Manifest entry: <id>

Review checklist:
  □ Verify Excel sheet exists matching feature base name
  □ Add test data row in Excel for testID '<featureBase>_001'
  □ Run feature locally to verify
  □ Commit when satisfied

To rollback: /scaffold-rollback <id>
```

---

## Critical rules

- **NEVER modify** files outside the destination paths and `fixtures.ts`
- **ALWAYS** update manifest.json after writing files
- **ALWAYS** ask user to confirm metadata + paths before transforming
- **NEVER** include login-related constants/methods/steps in generated files
- **PRESERVE** the user's existing fixtures.ts structure — only ADD, never reorder
- If transformation fails partway through, **list which files were created** so user can clean up manually
