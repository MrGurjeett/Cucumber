# /scaffold-rollback

## Purpose
Undo a previous `/scaffold-bdd` operation by:
1. Deleting all files created by that scaffold
2. Removing all lines added to `fixtures.ts` by that scaffold
3. Removing the entry from `manifest.json`

This is the safety net that lets the user delete files when they're not happy with the generated output.

---

## Step 1 — Read manifest

Read `.features-gen/manifest.json`.

If missing or empty (`{"scaffolds":[]}`):
- Report: "No scaffolds to rollback. Manifest is empty."
- STOP

---

## Step 2 — Get rollback target

The command may be invoked as:
- `/scaffold-rollback` (no argument) → show list, ask user to pick
- `/scaffold-rollback <id>` → use that id directly
- `/scaffold-rollback last` → use the most recent entry

If no argument:

Display all entries with index numbers:
```
Available scaffolds to rollback:

  [1] moneyMovementEnrollment-2026-05-25T14-30-00
      Created: 2026-05-25 14:30
      Files: 4
      Class: MoneyMovementEnrollmentPage
      Domain: SelfEnrollment

  [2] transferAccounts-2026-05-25T10-15-00
      Created: 2026-05-25 10:15
      Files: 4
      Class: TransferAccountsPage
      Domain: Accounts

Type the number, id, or 'last' to rollback. Type 'cancel' to abort.
```

WAIT for user response.

If user types `cancel` or doesn't respond meaningfully, STOP.

---

## Step 3 — Confirm

Show what WILL be deleted:

```
🗑  ROLLBACK PREVIEW: <id>

Files to be deleted:
  ❌ src/wpa/pages/UI/<Domain>/<ClassName>.ts
  ❌ src/wpa/constants/UI/<Domain>/<ClassName>Constants.ts
  ❌ src/wpa/tests/UI/steps/<Domain>/<fixtureBaseName>Steps.ts
  ❌ src/resources/features/UI/<Domain>/<featureBase>.feature

fixtures.ts lines to remove:
  - import <ClassName> from '@pages/UI/<Domain>/<ClassName>';
  - <fixtureVarName>: <ClassName>;
  - registry.<fixtureVarName> = refreshInstance(...);
  - registry.<fixtureVarName> = refreshInstance(... newPage);
  - <fixtureVarName>: async ({ pageObjects }, use) => { ... },

⚠  This action cannot be undone.
Type 'yes' to confirm rollback, anything else to cancel.
```

WAIT for confirmation. If not exactly `yes`, STOP and report cancellation.

---

## Step 4 — Execute rollback

### 4a. Delete files
For each entry in `files_created`, delete the file. If a file doesn't exist (user already deleted manually), log a warning but continue.

Track which files were actually deleted vs. already-missing.

### 4b. Update fixtures.ts
Read `fixtures.ts`. For each of the 5 entries in `fixtures_modified`:
- Search for the exact string
- Delete the entire line containing it (including trailing newline)

If a line is not found (user already removed manually), log a warning but continue.

**Important:** Match by exact string from the manifest, not by regex. This ensures we only remove what we added.

Write the modified `fixtures.ts` back.

### 4c. Remove from manifest
Read `manifest.json`. Filter out the entry with matching `id`. Write back.

---

## Step 5 — Report

```
✅ ROLLBACK COMPLETE: <id>

Files deleted:
  ✅ src/wpa/pages/UI/<Domain>/<ClassName>.ts
  ✅ src/wpa/constants/UI/<Domain>/<ClassName>Constants.ts
  ⚠  src/wpa/tests/UI/steps/<Domain>/<fixtureBaseName>Steps.ts (already missing)
  ✅ src/resources/features/UI/<Domain>/<featureBase>.feature

fixtures.ts updated:
  ✅ Import removed
  ✅ Interface entry removed
  ✅ Registry entry removed
  ✅ Reset entry removed
  ⚠  Accessor entry not found (already removed)

Manifest entry removed: <id>

Remaining scaffolds: 1
```

---

## Critical rules

- **NEVER** delete files NOT listed in the manifest
- **NEVER** modify `fixtures.ts` lines that are NOT in `fixtures_modified`
- **ALWAYS** confirm before destructive operations
- **ALWAYS** report which actions succeeded vs failed
- If `fixtures.ts` was manually edited and our exact string isn't found, do NOT guess — skip and warn
- Only ONE scaffold can be rolled back per command invocation
