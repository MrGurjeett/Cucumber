# GitHub Copilot Instructions
# WPA Playwright BDD Automation Framework — v4

## Project Overview
Playwright + playwright-bdd TypeScript automation for Wealth Passport (WPA).
BDD tests using Gherkin feature files. Tests are data-driven via Excel files.

---

## Folder Conventions

```
src/
  utils/                                 ← shared utilities (NOT src/wpa/utils)
    stepWrapper.ts
    CommonActionsPage.ts
    LoginPages.ts
    SessionManager.ts
    SessionState.ts
  wpa/
    constants/UI/<Domain>/<PageName>Constants.ts
    pages/UI/<Domain>/<PageName>.ts
    tests/UI/steps/<Domain>/<PageName>Steps.ts
    tests/UI/steps/fixtures.ts
  resources/
    features/UI/<Domain>/<name>.feature
    testdata/                            ← Excel test data files live here
```

---

## Import Paths — Critical

```typescript
// ✅ CORRECT
import { executeStep } from 'utils/stepWrapper';
import CommonActionsPage from 'utils/CommonActionsPage';
import Login from 'utils/LoginPages';
import { SessionState } from 'utils/SessionState';

// ❌ WRONG — never use this path
import { executeStep } from 'wpa/utils/stepWrapper';
```

The `tsconfig.json` baseUrl is `./src` so `utils/*` resolves to `src/utils/*` directly.

---

## Login Pattern — ALWAYS USE THESE TWO STEPS

Every feature file MUST start with exactly these two steps — no exceptions:

```gherkin
Given I Navigate to Wealth Passport Application
When The Wealth Passport Refresh application for PMM is loaded based on "<LoginUser>"
```

Their step definitions are ALREADY defined in existing step files.
NEVER generate new login step definitions. NEVER hardcode credentials.
LoginUser comes from the Examples table e.g. `tran_ExternalAdminInitiator_DEMOW`.

---

## Test Data Pattern — Excel-driven, never hardcoded

All test data values come from Excel files at runtime via `loadTestData()`.

### In feature files:
```gherkin
Scenario Outline: My test scenario
  Given I Navigate to Wealth Passport Application
  When The Wealth Passport Refresh application for PMM is loaded based on "<LoginUser>"
  And User loads test data for '<testID>'
  Then I do something

  Examples:
    | LoginUser                          | testID          |
    | tran_ExternalAdminInitiator_DEMOW  | MyFeature_001   |
```

### In page class:
```typescript
private testDataCache: Record<string, string> | null = null;

async loadTestData(testID: string, featureBaseName: string): Promise<void> {
  if (this.testDataCache) return;
  const excelFile = this.commonActions.buildExcelFilePath(featureBaseName);
  const rows      = await this.commonActions.readExcelAsTableOfASheet(excelFile, featureBaseName);
  const row       = rows.find((r: any) =>
    String(r.TestId).trim().toUpperCase() === testID.toUpperCase() &&
    String(r.ExecutionFlag ?? 'Y').trim().toUpperCase() === 'Y'
  );
  if (!row) throw new Error(`Test data not found for TestId=${testID}`);
  this.testDataCache = row as Record<string, string>;
}
```

### In step definitions:
```typescript
import { executeStep } from 'utils/stepWrapper';   // src/utils/stepWrapper

Then('User loads test data for {string}',
  async ({ myPage, reporting }, testID: string) => {
    try {
      await myPage.loadTestData(testID, 'MyFeature');
      await reporting.logResult('Load test data', `TestId: ${testID}`,
        'Test data loaded successfully', 'Pass', 'Screenshot');
    } catch (error: any) {
      const errorMsg = (error && typeof error === 'object' && 'message' in error)
        ? (error as any).message : String(error);
      await reporting.logResult('Load test data', `TestId: ${testID}`,
        `Failed to load test data: ${errorMsg}`, 'Fail', 'Screenshot');
      throw error;
    }
});
```

---

## Page Class Rules

- NO base class — standalone like `UsersDetailsPage.ts`
- Private fields always in this exact order:
```typescript
private web: UIActions;
private logger: typeof Logger;
private reporting: ATRService;
private commonActions: CommonActionsPage;
private testDataCache: Record<string, string> | null = null;
```
- Constructor always initialises all four service fields
- `handleError` always private inside the page class
- Error message pattern in catch:
```typescript
const errorMsg = (error && typeof error === 'object' && 'message' in error)
  ? (error as any).message : String(error);
```

---

## Constants File Rules

- ONLY URLs, labels, placeholders, selectors go here
- NEVER put test data values (_VALUE constants) in constants file
- Those go in Excel and are accessed via `this.testDataCache`

---

## Step Definition Rules

- Import from `'../fixtures'` — never from `'playwright-bdd'` directly
- Import `executeStep` from `'utils/stepWrapper'` — not `'wpa/utils/stepWrapper'`
- Fixture names: `reporting` (ATRService), camelCase page name
- NEVER use `atrService` — always `reporting`
- NEVER define new login steps — they already exist

---

## What Copilot Should NEVER Do

- Never hardcode test data values (user IDs, passwords, account numbers)
- Never generate login step definitions — they already exist
- Never use `atrService` as fixture name — always `reporting`
- Never put `_VALUE` constants in the constants file
- Never import from `wpa/utils/` — utils live at `src/utils/` directly
- Never create a Scenario without an Examples table

---

## Scaffold Slash Commands

This workspace has two slash commands for BDD scaffolding (`.github/prompts/`):

### `/scaffold-bdd`
Transforms SQM Minion output in `.features-gen/raw-output.txt` into framework-aligned files. Updates `fixtures.ts`. Tracks operation in `.features-gen/manifest.json` for rollback.

This is the **intelligent alternative** to running `npx ts-node scripts/scaffold-generated-test.ts`.

### `/scaffold-rollback`
Undoes a previous `/scaffold-bdd` operation. Reads `manifest.json`, asks user which scaffold to undo, then deletes the files and reverts `fixtures.ts` changes.

Usage:
- `/scaffold-rollback` → show list, ask user to pick
- `/scaffold-rollback last` → undo most recent
- `/scaffold-rollback <id>` → undo specific scaffold by id

When these slash commands run, follow the instructions in the corresponding `.prompt.md` file exactly.
