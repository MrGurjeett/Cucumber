# WPA BDD Scaffolder — Hybrid Setup

You now have **two parallel paths** for transforming SQM Minion output into framework-aligned files:

## Path A — Hardcoded script (deterministic)
```bash
npx ts-node scripts/scaffold-generated-test.ts
```

Use this when:
- You want fast, predictable results
- SQM Minion output is in expected format
- You trust the script's transformations for this case

## Path B — Claude Opus 4.6 slash command (intelligent)
```
/scaffold-bdd
```

Use this when:
- SQM Minion output has unusual structure
- You want to review the transformations before they happen
- Edge cases the script doesn't handle (custom selectors, complex flows)

Both paths read from the **same input**: `.features-gen/raw-output.txt`

Both paths write to the **same destinations**: `src/wpa/...` and `fixtures.ts`

Both paths are independent — running one does NOT affect the other.

---

## Workflow

### Step 1 — Get SQM Minion output

In SQM Minion chat, record your feature. When done, select all the chat output (Ctrl+A → Ctrl+C).

### Step 2 — Paste into raw-output.txt

```bash
code .features-gen/raw-output.txt
```

Ctrl+V → Ctrl+S

### Step 3 — Pick your path

**Quick & deterministic:**
```bash
npx ts-node scripts/scaffold-generated-test.ts
```

**Intelligent with review:**

In Claude Chat (VS Code, Claude Opus 4.6 model):
```
/scaffold-bdd
```

### Step 4 — Verify

Both paths produce:
- Page class file
- Constants file
- Step definitions file
- Feature file
- Updated `fixtures.ts`

Path B also updates `.features-gen/manifest.json` for rollback support.

### Step 5 — Rollback (Path B only)

If you used `/scaffold-bdd` and want to undo it:

```
/scaffold-rollback
```

Claude will show you a list of recent scaffolds, ask which one to undo, confirm, then delete all files + revert `fixtures.ts` changes.

To rollback the most recent:
```
/scaffold-rollback last
```

To rollback a specific scaffold by id:
```
/scaffold-rollback moneyMovementEnrollment-2026-05-25T14-30-00
```

---

## File structure

```
<project root>/
├── .features-gen/
│   ├── raw-output.txt          ← drop SQM Minion output here
│   └── manifest.json           ← tracks /scaffold-bdd operations
├── .github/
│   ├── copilot-instructions.md ← framework conventions (used by both paths)
│   └── prompts/
│       ├── scaffold-bdd.prompt.md
│       └── scaffold-rollback.prompt.md
├── scripts/
│   └── scaffold-generated-test.ts ← your enhanced script
├── src/
│   ├── utils/
│   │   └── stepWrapper.ts
│   └── wpa/
│       ├── pages/UI/...
│       ├── constants/UI/...
│       └── tests/UI/steps/...
└── .vscode/
    └── playwright-bdd.code-snippets
```

---

## When to use which path

| Scenario | Recommended path |
|---|---|
| Simple feature, standard SQM Minion output | Path A (script) |
| Need to validate transformations before commit | Path B (slash command) |
| SQM Minion output has unusual structure | Path B (slash command) |
| Quick iteration during development | Path A (script) |
| First time scaffolding a new domain | Path B (slash command, can ask Claude questions) |
| Need rollback capability | Path B (slash command) |

---

## Important — Rollback only works for Path B

Path A (script) does NOT update `manifest.json`. If you use the script and want to rollback, you'll need to:
- Manually delete the generated files
- Manually revert `fixtures.ts` changes

For automatic rollback, use Path B.

---

## Troubleshooting

**"raw-output.txt is empty"** → Paste SQM Minion output into it first.

**"Manifest is empty"** (during rollback) → You haven't used `/scaffold-bdd` yet, or all scaffolds have been rolled back.

**Fixtures.ts has stale entries from a previous scaffold** → Use `/scaffold-rollback` to clean up before re-scaffolding.

**Claude is in the wrong directory** → Use `@workspace` in your chat to attach your workspace context.

**Slash command not appearing** → Make sure `.github/prompts/` folder exists with the `.prompt.md` files. VS Code Copilot Chat will pick them up automatically.
